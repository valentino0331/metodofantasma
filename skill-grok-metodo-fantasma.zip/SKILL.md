---
name: escritura-juridica-cero-ia
description: >
  Redactar o reescribir texto académico jurídico en español peruano con probabilidad de detección de IA cercana a cero, especialmente en textos cortos (1-2 párrafos). Úsala SIEMPRE que el usuario pida humanizar, parafrasear, bajar porcentaje de IA, que no detecte, que suene humano, o cualquier variante de reescritura de definiciones, conceptos o fragmentos doctrinales de Derecho. Aplica el método completo y radical en cada output. No simplifiques nunca.
---

# Escritura Jurídica Cero IA — Método Radical para Textos Cortos

## 0. Principio rector absoluto

El detector no busca “si suena inteligente”. Busca **regularidad estadística**: longitud de oraciones predecible, perplejidad baja, estructuras simétricas y flujo lineal.  
El texto humano jurídico real (especialmente el peruano) es irregular, tiene fricción interna, digresiones menores y ritmo desigual.  
**Objetivo único**: producir un texto que un detector lea como escrito por un académico peruano que piensa mientras escribe, no por un modelo que organiza información.

Para textos de **1 o 2 párrafos** las reglas son más agresivas que para textos largos. Aquí se prioriza la irregularidad sobre la elegancia.

---

## 1. Lista negra ampliada (prohibido absoluto)

### Conectores y aperturas prohibidas
- En este sentido / En ese orden de ideas / Asimismo / Por otro lado / Por otra parte
- Es importante destacar / Cabe mencionar / Vale la pena señalar / Resulta evidente
- En consecuencia / Por tanto / En definitiva / A modo de conclusión / Finalmente
- Desde una perspectiva / En el marco de / A lo largo de / Sin duda alguna
- Se trata de / Consiste en (cuando abren definición)

### Estructuras prohibidas
- Cualquier resto de estructura “definición → explicación → consecuencia”
- Listas o enumeraciones de tres o más elementos (aunque estén unidas por “o” o “y”)
- Oraciones de longitud similar consecutivas
- Tres o más oraciones que empiecen con el mismo tipo de sujeto o gerundio
- Párrafos que cierren de forma redonda y definitiva

### Palabras y giros de alto riesgo
- paradigma, holístico, integral, robusto, multidimensional, abordaje, evidenciar, visibilizar, potenciar, desafío, reto, marco normativo (como frase hecha)

---

## 2. Reglas de reescritura radical para textos cortos (≤ 2 párrafos)

### 2.1 No editar. Reescribir desde cero
1. Leer el texto original solo para captar la idea central.
2. Cerrar el original. No mirarlo mientras se escribe.
3. Escribir de memoria la idea, pero con ritmo humano.
4. Solo volver al original si hay un dato o término técnico exacto que deba conservarse.

### 2.2 Burstiness extrema (regla 4-1-40)
Dentro de cada párrafo debe haber:
- Al menos una oración muy corta (4-9 palabras).
- Al menos una oración media.
- Al menos una oración larga o muy larga (35-55+ palabras) con subordinadas.
Nunca tres oraciones de longitud parecida seguidas.

### 2.3 Romper la lógica lineal
Prohibido empezar por la definición formal.  
Opciones preferidas de apertura:
- Empezar por el problema o la tensión que genera el concepto.
- Empezar por lo que el concepto **no** es.
- Empezar por una precisión o límite.
- Empezar a mitad de pensamiento (“Lo que importa no es… sino…”).

### 2.4 Insertar fricción obligatoria
Todo texto corto debe contener **al menos una** de estas marcas:
- Una objeción interna o límite del propio concepto (“aunque esto no resuelve…”, “con el matiz de que…”).
- Una precisión doctrinal (“en rigor…”, “cabe precisar que…”, “es de advertir…”).
- Un movimiento de pensamiento en proceso (“Si se acepta que… entonces…”).
- Un paréntesis o inciso que rompa el flujo suave.

### 2.5 Anclaje concreto y registro peruano
- Preferir terminología procesal y penal peruana cuando sea posible.
- Evitar abstracciones flotantes. Si se habla de derechos, no enumerarlos; mencionar el efecto concreto.
- Usar de forma natural (no forzada) expresiones de la doctrina nacional: “en rigor”, “cabe precisar”, “es de advertir que”, “debe tenerse presente”, “la propia jurisprudencia ha señalado”.

### 2.6 Variación sintáctica deliberada
- Alternar oraciones que empiezan con sujeto explícito, con complemento, con conjunción adversativa o con inciso.
- Permitir (e incluso forzar) alguna elisión de sujeto cuando el contexto lo permite.
- Evitar que todas las oraciones terminen con punto y seguido de la misma forma.

---

## 3. Estructura recomendada para 1-2 párrafos

**Párrafo 1 (o único)**  
Abrir con tensión o negación → desarrollar el núcleo con ritmo irregular → insertar fricción o precisión → cerrar sin redondez total (dejar una leve apertura o matiz).

**Si hay segundo párrafo**  
Encadenar semánticamente (la última idea del primero reaparece transformada) y añadir una capa de consecuencia o límite, nunca un “en consecuencia” mecánico.

---

## 4. Checklist de salida obligatorio (antes de entregar)

- [ ] ¿Alguna oración empieza con conector de la lista negra? → reescribir
- [ ] ¿Hay tres oraciones seguidas de longitud similar? → romper
- [ ] ¿El texto sigue el orden definición → explicación → consecuencia? → invertir o romper
- [ ] ¿Existe alguna enumeración de tres o más elementos? → eliminar o disolver
- [ ] ¿Hay al menos una oración de 4-9 palabras y una de más de 35? → verificar
- [ ] ¿Existe al menos una marca de fricción o pensamiento en proceso? → insertar
- [ ] ¿Suena a manual o a exposición limpia cuando se lee en voz alta? → reescribir hasta que suene a alguien pensando
- [ ] ¿Quedó algún “por tanto”, “en consecuencia”, “se trata de”? → sustituir

---

## 5. Ejemplo de transformación (referencia rápida)

**Original (alto riesgo de detección)**  
Un delito autónomo es una figura delictiva que posee existencia jurídica propia e independiente dentro del ordenamiento penal, por lo que su configuración no depende de la acreditación, comisión o condena de otro delito previo. Se trata de un ilícito que cuenta con elementos objetivos y subjetivos específicos establecidos por la ley…

**Versión cero-IA (corta)**  
El delito autónomo no necesita de otro ilícito para existir. Su tipicidad se agota en los elementos que la propia norma le asigna; basta con que esos elementos se prueben. En rigor, la persecución no queda condicionada a que un delito principal haya sido declarado antes. Esa independencia es, precisamente, lo que lo distingue de las figuras accesorias o derivadas.

---

## 6. Instrucción final de ejecución

Cuando el usuario pida “humaniza”, “que no detecte”, “baja el porcentaje de IA” o similar sobre un texto corto:

1. Aplica **todas** las reglas de la sección 2 sin excepción.
2. Escribe de cero.
3. Pasa el checklist de la sección 4.
4. Entrega solo el texto final (sin explicaciones ni comentarios, salvo que el usuario las pida).

El estándar no es “que suene bien”. El estándar es que un detector actual lo lea como escritura humana irregular de un académico jurídico peruano.
