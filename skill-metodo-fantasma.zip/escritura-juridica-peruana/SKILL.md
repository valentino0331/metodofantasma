---
name: escritura-juridica-peruana
description: "Redactar, reescribir o revisar texto académico jurídico en español con probabilidad cero de detección como contenido generado por IA. Úsala SIEMPRE que Rafael pida escribir, parafrasear, expandir, revisar o corregir cualquier sección de una tesis, artículo científico, ensayo jurídico, ponencia o cualquier documento académico de Derecho. También activa esta skill cuando el usuario mencione \"que suene humano\", \"bajar el porcentaje de IA\", \"que no detecte\", \"registro académico\", \"parafrasear para tesis\", \"redactar argumento jurídico\" o cualquier variante. Aplica el método completo en cada output — no lo simplifiques aunque la tarea parezca pequeña."
---

#Método 0% IA

## Contexto de origen

Esta skill fue construida y refinada durante la elaboración de la tesis de pregrado de Rafael Ortega (UCV Piura, 2026): *"La regulación de contenidos manipulados con Inteligencia Artificial como delito autónomo en la legislación peruana y comparada"*. El método emergió de iteraciones sucesivas hasta lograr 0% de probabilidad de IA en detectores estándar, manteniendo el rigor académico jurídico exigido por la universidad.

---

## 1. Principios fundacionales

### 1.1 Escribir desde la argumentación, no desde el dato

El error más común del texto generado por IA es comenzar por el dato o la definición y luego construir hacia la conclusión. El académico jurídico hace lo inverso: parte de la tensión normativa, la contradicción doctrinal o el vacío legal, y desde ahí convoca las fuentes. Cada párrafo debe tener una tesis implícita antes de citar.

### 1.2 Voz propia antes que síntesis de fuentes

El texto IA tiende a ser "orquestador de fuentes": presenta lo que dice A, luego B, luego concluye con C. El texto humano muestra una postura y usa las fuentes como evidencia o interlocutor crítico. Siempre hay un "el autor sostiene que…" antes del "tal como señala X".

### 1.3 Registro académico jurídico peruano específico

No es español académico genérico. Tiene marcas propias:
- Uso del gerundio con moderación y solo cuando es gramaticalmente correcto
- Preferencia por el indicativo sobre el subjuntivo en afirmaciones doctrinales
- Citas integradas al flujo, no en bloque aparte
- Terminología procesal y penal peruana (no trasplantar conceptos de España o Argentina sin marcarlos)
- Presencia ocasional de expresiones de la doctrina nacional: "en rigor", "cabe precisar", "es de advertir que", "debe tenerse presente"

---

## 2. Lista negra — Patrones que activan detectores de IA

Nunca usar estas estructuras. Son marcadores universales de texto generado:

### Conectores y frases de apertura prohibidos
- "En este sentido…"
- "En ese orden de ideas…"
- "Es importante destacar que…"
- "Cabe mencionar que…" (a secas, sin necesidad argumentativa)
- "Asimismo…" como conector automático entre párrafos
- "Por otro lado…" / "Por otra parte…" como par mecánico
- "En conclusión…" / "En definitiva…" al cierre de cada sección
- "A modo de conclusión…"
- "Es fundamental subrayar…"
- "Sin duda alguna…"
- "Resulta evidente que…"
- "Vale la pena señalar…"
- "En el marco de…" como apertura de párrafo
- "A lo largo de…" como apertura
- "Finalmente, cabe señalar…"

### Estructuras sintácticas prohibidas
- Tres elementos en lista paralela dentro de una misma oración (el LLM ama el tricolon)
- Oraciones que comienzan con participio absoluto: "Reconociendo la complejidad del tema, …"
- Párrafos que abren con definición + aplicación + conclusión en ese orden fijo
- Uso de dos puntos para introducir listas en cada párrafo
- Repetición del sujeto explícito en oraciones consecutivas cuando el contexto lo permite elidir

### Palabras de alto riesgo (usar con restricción extrema)
- "paradigma", "holístico", "integral", "robusto", "multidimensional"
- "abordaje", "abordar" (sustituir por "tratar", "examinar", "analizar")
- "evidenciar" como sinónimo de "mostrar" o "demostrar"
- "visibilizar"
- "potenciar", "fortalecer" en sentido abstracto
- "desafío" / "reto" como sustantivos autónomos ("el desafío de…")
- "marco normativo" como frase hecha sin necesidad
- "la presente investigación" en exceso (máximo una vez por sección)

---

## 3. Técnicas activas de escritura humana

### 3.1 Variación de longitud de oraciones — Regla del 3-1-5

Dentro de cada párrafo, alternar: una oración larga (estructura compleja con subordinada), una corta (sujeto + verbo + complemento directo), una media. Nunca tres oraciones del mismo tipo seguidas.

**Ejemplo incorrecto (IA):**
> La regulación de los contenidos manipulados con inteligencia artificial representa un desafío normativo de gran magnitud. Es importante destacar que dicha regulación debe considerar múltiples dimensiones. En este sentido, el legislador peruano enfrenta el reto de equilibrar la libertad de expresión con la protección de bienes jurídicos fundamentales.

**Ejemplo correcto (humano):**
> El legislador peruano se encuentra ante una encrucijada que la doctrina clásica no anticipó: ¿cómo sancionar un contenido cuya autoría material recae en un sistema algorítmico? La respuesta no es trivial. Tipificar la conducta exige redefinir el concepto de autoría en términos que el Código Penal de 1991 no contempló, lo que abre, a su vez, la discusión sobre si la reforma debe ser parcheada o estructural.

### 3.2 Ruptura de paralelismos

El texto IA genera listas paralelas de manera compulsiva. El texto humano rompe la simetría cuando la argumentación lo exige.

**IA:** "La norma debe ser clara, precisa y aplicable."
**Humano:** "La norma debe ser clara; la precisión, en cambio, depende del intérprete."

### 3.3 Insertar fricción argumentativa

Los textos académicos humanos no fluyen sin resistencia. Incluir:
- Objeciones dentro del propio argumento antes de refutarlas
- Reconocimiento de límites del argumento propio: "aunque esta postura no resuelve el problema de…"
- Tensiones no resueltas al final de secciones intermedias

### 3.4 Marcas de pensamiento en proceso

El académico humano a veces muestra el razonamiento, no solo la conclusión:
- "Si se acepta que X, entonces Y se vuelve insostenible…"
- "La pregunta que subyace a este debate es si…"
- "Esto nos lleva a una cuestión previa que la doctrina ha soslayado…"

### 3.5 Especificidad sobre generalidad

El texto IA tiende a la abstracción. El texto humano ancla en lo concreto:
- En lugar de "la legislación comparada" → "el artículo 4 del Reglamento UE 2024/1689 (EU AI Act)"
- En lugar de "los expertos señalan" → "Ferrajoli advierte, en su crítica al derecho penal del enemigo, que…"
- En lugar de "existen estudios que muestran" → cifra, fecha, fuente específica

---

## 4. Estructura párrafo a párrafo

Cada párrafo sigue esta lógica (no necesariamente este orden visible):

1. **Tesis del párrafo** — qué se afirma
2. **Soporte** — doctrina, norma, jurisprudencia o dato empírico
3. **Movimiento argumentativo** — qué implica ese soporte para la tesis
4. **Conexión** — cómo enlaza con el párrafo siguiente (sin usar conectores automáticos)

La conexión se hace preferiblemente por **encadenamiento semántico**: la última palabra o idea del párrafo reaparece transformada en la primera del siguiente.

---

## 5. Flujo de trabajo por tipo de texto

### 5A — Sección de tesis (marco teórico, resultados, discusión)

1. Leer el objetivo específico que corresponde a esa sección
2. Identificar la tensión o vacío que esa sección debe resolver
3. Redactar la tesis de la sección en una oración (no aparece en el texto, es guía)
4. Construir 3-5 párrafos siguiendo la estructura del punto 4
5. Revisar pasando por la lista negra del punto 2
6. Verificar variación de longitud de oraciones (punto 3.1)
7. Si hay citas: integrarlas al flujo, no como bloques aislados

### 5B — Artículo científico derivado (para revistas indexadas)

Igual que 5A pero con atención adicional a:
- Abstract en español e inglés: máximo 250 palabras, sin conectores IA, con resultados explícitos
- Palabras clave: 4-6, al menos 2 deben aparecer en el título
- Introducción: plantear el problema con datos empíricos antes de la revisión de literatura
- Discusión: contrastar hallazgos con literatura previa, no solo resumirla
- Conclusiones: responder directamente las preguntas de investigación, sin generalizar

### 5C — Reescritura / parafraseo de texto generado por IA

1. Leer el texto completo para captar la idea central
2. **No editar palabra por palabra** — ese método conserva la estructura IA
3. Escribir de cero a partir de la idea, usando solo la memoria de lo leído
4. Si hay citas o datos específicos, volver al original solo para copiarlos con precisión
5. Aplicar lista negra del punto 2 al output
6. Releer en voz alta — si suena a locución corporativa, reescribir

---

## 6. Registro por sección de tesis peruana

| Sección | Tono | Densidad citas | Riesgo IA alto |
|---|---|---|---|
| Planteamiento del problema | Descriptivo-argumentativo | Baja | Uso de "evidenciar", "visibilizar" |
| Marco teórico | Expositivo-crítico | Alta | Tricolon, conectores automáticos |
| Metodología | Técnico-neutro | Media | Párrafos paralelos, "abordaje" |
| Resultados | Analítico | Baja | Síntesis sin postura |
| Discusión | Argumentativo | Alta | Listas, ausencia de fricción |
| Conclusiones | Sintético-asertivo | Baja | "En conclusión", generalización |

---

## 7. Test de salida antes de entregar

Antes de presentar cualquier texto al usuario, pasar mentalmente este checklist:

- [ ] ¿Alguna oración empieza con conector prohibido? → reescribir
- [ ] ¿Hay tres oraciones seguidas de longitud similar? → romper
- [ ] ¿Algún párrafo tiene estructura definición→aplicación→conclusión sin fricción? → insertar objeción
- [ ] ¿Se usa "evidenciar", "abordar", "fortalecer", "desafío" sin necesidad? → sustituir
- [ ] ¿Las citas están integradas o son bloques flotantes? → integrar
- [ ] ¿El texto suena igual leído en voz alta que en silencio? → si sí, añadir variación

---

## 8. Ejemplos de referencia rápida

### Marco teórico — fragmento bien construido

> La teoría del garantismo penal elaborada por Luigi Ferrajoli no fue concebida para operar en entornos digitales; su arquitectura conceptual presupone un sujeto imputable cuya conducta puede ser reconstruida mediante prueba. Esa presunción se fractura cuando el agente productor del contenido ilícito es un modelo de lenguaje que genera texto probabilísticamente, sin intención en el sentido psicológico que exige el dolo penal. No basta, entonces, con trasladar las categorías del garantismo al campo digital: es necesario examinar si sus axiomas de legalidad y culpabilidad admiten reformulación o si, por el contrario, el fenómeno exige una teoría autónoma.

### Discusión — fragmento bien construido

> Los entrevistados coincidieron en que la legislación vigente es insuficiente, pero divergieron en el diagnóstico. Mientras E3 y E7 señalaron que el problema es de tipificación —el tipo penal no contempla al sistema de IA como instrumento—, E1 y E5 ubicaron la deficiencia en la fase probatoria: la dificultad de acreditar la autoría mediata cuando el intermediario es un algoritmo. Esa divergencia no es menor. Si la solución está en el tipo, alcanza con una reforma puntual al artículo 9 de la Ley N° 30096. Si está en la prueba, la reforma legislativa es condición necesaria pero no suficiente: se requiere además protocolo pericial especializado que las fiscalías peruanas no tienen.

---

*Skill construida a partir del proceso de tesis de Rafael Ortega (UCV Piura, 2026). Actualizar cuando se incorporen nuevos patrones identificados en artículos derivados.*